package com.wxson.mobilecomm.mvp;

/**
 * Created by wxson on 2018/2/1.
 */

public interface IBaseView<T> {
    void setPresenter(T presenter);
}
