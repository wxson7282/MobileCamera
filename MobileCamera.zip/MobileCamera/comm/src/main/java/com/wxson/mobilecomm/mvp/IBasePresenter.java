package com.wxson.mobilecomm.mvp;

/**
 * Created by wxson on 2018/2/1.
 */

public interface IBasePresenter {
    void start();
}
